import difflib

def check_plagiarism(text1, text2, threshold=0.8):
    """
    Checks for plagiarism between two texts.

    Parameters:
        text1 (str): The first text to compare.
        text2 (str): The second text to compare.
        threshold (float): Similarity threshold. A value closer to 1.0 means stricter matching.

    Returns:
        bool: True if the similarity ratio is above the threshold; False otherwise.
    """
    # Calculate the similarity ratio between the two texts
    similarity_ratio = difflib.SequenceMatcher(None, text1, text2).ratio()

    # Check if the similarity ratio is above the threshold
    return similarity_ratio >= threshold

if __name__ == "__main__":
    # Example usage
    text1 = "This is a sample text for testing."
    text2 = "1234"

    is_plagiarized = check_plagiarism(text1, text2)
    if is_plagiarized:
        print("Plagiarism detected.")
    else:
        print("No plagiarism detected.")
